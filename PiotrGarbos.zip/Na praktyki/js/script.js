const burger = document.querySelector(".burger");
const navol = document.querySelector(".navol");

burger.addEventListener('click', () => {
    burger.classList.toggle("active");
    navol.classList.toggle("active");
});